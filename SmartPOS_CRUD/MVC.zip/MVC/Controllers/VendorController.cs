﻿using MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.Net.Http;

namespace MVC.Controllers
{
    public class VendorController : Controller
    {
        // GET: Vendor
        public ActionResult Index()
        {
            IEnumerable<mvcVendorModel> vendors;
            HttpResponseMessage response = GlobalHttp.WebApiClient.GetAsync("Vendors").Result;
            vendors = response.Content.ReadAsAsync<IEnumerable<mvcVendorModel>>().Result;
            
            return View(vendors);
        }

        public  ActionResult Profile(int id)
        {
            mvcVendorModel vendor;
            HttpResponseMessage response = GlobalHttp.WebApiClient.GetAsync("Vendors/" + id.ToString()).Result;
            vendor = response.Content.ReadAsAsync<mvcVendorModel>().Result;
            return View(vendor);
        }
        public ActionResult AddOrEdit(int id = 0)
        {
            if (id == 0)
            {
                return View(new mvcVendorModel());
            }
            else
            {
                mvcVendorModel vendor;
                HttpResponseMessage response = GlobalHttp.WebApiClient.GetAsync("Vendors/" + id.ToString()).Result;
                vendor = response.Content.ReadAsAsync<mvcVendorModel>().Result;
                return View(vendor);
            }

        }


        [HttpPost]
        public ActionResult AddOrEdit(mvcVendorModel vendor)
        {
            if (vendor.VendorId == 0)
            {

            }
            else
            {

            }
            return RedirectToAction("Index");

        }
    }
}